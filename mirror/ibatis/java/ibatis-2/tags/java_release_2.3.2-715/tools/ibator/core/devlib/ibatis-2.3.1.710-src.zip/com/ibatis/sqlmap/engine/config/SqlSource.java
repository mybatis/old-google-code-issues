package com.ibatis.sqlmap.engine.config;

import com.ibatis.sqlmap.engine.mapping.sql.*;

public interface SqlSource {
  Sql getSql();

}
